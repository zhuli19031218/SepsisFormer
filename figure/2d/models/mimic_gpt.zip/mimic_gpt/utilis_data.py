import os
import time
import torch
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def stander_data(data):
    '''
    标准化
    :return:
    '''
   

    data = data.iloc[:, :]
    data = data.apply(lambda x: (x - x.min()) / (x.max() - x.min()), axis=0)

    return data

class TabDataset(Dataset):
    def __init__(self, data, target=None):
        super().__init__()
        self.data = data
        self.target = target

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        data = self.data[idx]
        _dict = {'data': torch.FloatTensor(data)}

        # data = self.data[idx]
        # # # print(type(data))  #<class 'numpy.ndarray'>
        # _dict = {'data': torch.tensor(data, dtype=torch.float)}

        if self.target is not None:
            target = self.target[idx].item()
            _dict.update({'target': torch.tensor(target, dtype=torch.float)})
        return _dict


# 读取原始数据
def get_data(path: str, logs):
    np.random.seed(256)
    pre_pyh_df = pd.read_csv(path).sample(frac=1)  # 原始数据，有表头
    # pre_pyh_df = pd.read_csv(path)
    pre_pyh_label = pre_pyh_df.pop('dead').to_numpy()

    pre_pyh_train_labels = torch.LongTensor(pre_pyh_label[:int(len(pre_pyh_df) * 0.5)])  # numpy->>>torch.tensor,int64
    pre_pyh_test_labels = torch.LongTensor(pre_pyh_label[int(len(pre_pyh_df) * 0.5):])  # numpy->>>torch.tensor,int64

    # # 'dongwuqixue'第一类,
    # Lactate     = pre_pyh_df.pop('Lactate')
    # pH          = pre_pyh_df.pop('pH')
    # Anion_Gap   = pre_pyh_df.pop('Anion Gap')
    # Bicarbonate = pre_pyh_df.pop('Bicarbonate')
    # Calcium     = pre_pyh_df.pop('Calcium')
    # Chloride    = pre_pyh_df.pop('Chloride')
    # Glucose     = pre_pyh_df.pop('Glucose')
    # Potassium   =  pre_pyh_df.pop('Potassium')
    # Sodium      = pre_pyh_df.pop('Sodium')
    # Hematocrit  = pre_pyh_df.pop('Hematocrit')
    # Hemoglobin  = pre_pyh_df.pop('Hemoglobin')

    # # # 'shengongneng'第二类,
    # Creatinine  = pre_pyh_df.pop('Creatinine')
    # UreaNitogen = pre_pyh_df.pop('UreaNitogen')
    # Magnesium   = pre_pyh_df.pop('Magnesium')
    # Phosphate   = pre_pyh_df.pop('Phosphate')
    #
    # # 'ningxuegongneng'第三类,
    # PT      = pre_pyh_df.pop('PT')
    # PTT     = pre_pyh_df.pop('PTT')
    # INR = pre_pyh_df.pop('INR(PT)')
    #
    # # 'yanzhengmianyi'第四类,
    # Lymphocytes       = pre_pyh_df.pop('Lymphocytes')
    # Monocytes         = pre_pyh_df.pop('Monocytes')
    # Neutrophil        = pre_pyh_df.pop('Neutrophil')
    # White_Blood_Cells = pre_pyh_df.pop('White_Blood_Cells')
    # Basophils         = pre_pyh_df.pop('Basophils')
    # Eosinophils       = pre_pyh_df.pop('Eosinophils')
    # Platelet_Count    = pre_pyh_df.pop('Platelet_Count')
    #
    # # 'gangongneng',第五类
    # AlanineAminotransferase  = pre_pyh_df.pop('AlanineAminotransferase(ALT)')
    # AlkalinePhosphatase      = pre_pyh_df.pop('AlkalinePhosphatase')
    # AspirateAminotransferase = pre_pyh_df.pop('AspirateAminotransferase(AST)')
    # Albumin                  = pre_pyh_df.pop('Albumin')
    # Bilirubin                = pre_pyh_df.pop('Bilirubin')
    # #
    # # # 'qita'其他
    # MCH             = pre_pyh_df.pop('MCH')
    # MCHC            = pre_pyh_df.pop('MCHC')
    # MCV             = pre_pyh_df.pop('MCV')
    # RDW             = pre_pyh_df.pop('RDW')
    # Red_Blood_Cells = pre_pyh_df.pop('Red _Blood_Cells')
    # patients_age    = pre_pyh_df.pop('patients_age')

    # pre_pyh_df.pop('SOFAscore')

    original_pre_pyh_train_inputs = pre_pyh_df[:int(len(pre_pyh_df) * 0.5)]  # (4964, 43)->(5673, 42)
    original_pre_pyh_test_inputs = pre_pyh_df[int(len(pre_pyh_df) * 0.5):]  # (2128, 43)->(1419, 42)
    print('原始训练集数据\n', original_pre_pyh_train_inputs[:10])
    print('原始测试集数据\n', original_pre_pyh_test_inputs[:10])
    original_pre_pyh_train_inputs.to_csv(os.path.join(logs, 'original_pre_pyh_train_features.csv'), index=False)
    original_pre_pyh_test_inputs.to_csv(os.path.join(logs, 'original_pre_pyh_test_features.csv'), index=False)

    standard_pre_pyh_df = stander_data(pre_pyh_df)
    standard_pre_pyh_train_inputs = standard_pre_pyh_df[:int(len(pre_pyh_df) * 0.5)].to_numpy()
    standard_pre_pyh_test_inputs = standard_pre_pyh_df[int(len(pre_pyh_df) * 0.5):].to_numpy()
    print('标准化后训练集数据\n', standard_pre_pyh_df[:int(len(pre_pyh_df) * 0.5)][:10])
    print('标准化后测试集数据\n', standard_pre_pyh_df[int(len(pre_pyh_df) * 0.5):][:10])

    return standard_pre_pyh_train_inputs, pre_pyh_train_labels, standard_pre_pyh_test_inputs, pre_pyh_test_labels

def pyh_dataloader(path:str, logs):
    pre_pyh_train_factors, pre_pyh_train_labels, pre_pyh_test_factors, \
    pre_pyh_test_labels = get_data(path, logs)

    pre_pyh_train_factors = torch.FloatTensor(pre_pyh_train_factors)  # torch.float32
    pre_pyh_test_factors = torch.FloatTensor(pre_pyh_test_factors)  # torch.float32

    return pre_pyh_train_factors, pre_pyh_train_labels, pre_pyh_test_factors, pre_pyh_test_labels

