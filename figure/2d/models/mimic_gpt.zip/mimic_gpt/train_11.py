import argparse
import os.path
import torch
from model_gpt_11 import *
from sklearn.metrics import auc, roc_auc_score, roc_curve
import copy
from utilis_data import *
from utilis_file import *
from torch.utils.tensorboard import SummaryWriter
from torchsummary import summary
import math
from captum.attr import IntegratedGradients
from image import draw_roc,draw_image
import torch.utils.data as Data
import warnings
warnings.filterwarnings("ignore")

class NMTCritierion(nn.Module):
    """
    1. Add label smoothing
    """
    def __init__(self, label_smoothing=0.0):
        super(NMTCritierion, self).__init__()
        self.label_smoothing = label_smoothing
        self.LogSoftmax = nn.LogSoftmax()

        if label_smoothing > 0:
            self.criterion = nn.KLDivLoss(size_average=False)
        else:
            self.criterion = nn.NLLLoss(size_average=False, ignore_index=100000)
        self.confidence = 1.0 - label_smoothing

    def _smooth_label(self, num_tokens):
        # When label smoothing is turned on,
        # KL-divergence between q_{smoothed ground truth prob.}(w)
        # and p_{prob. computed by model}(w) is minimized.
        # If label smoothing value is set to zero, the loss
        # is equivalent to NLLLoss or CrossEntropyLoss.
        # All non-true labels are uniformly set to low-confidence.
        one_hot = torch.randn(1, num_tokens)
        one_hot.fill_(self.label_smoothing / (num_tokens - 1))
        return one_hot

    def _bottle(self, v):
        return v.view(-1, v.size(2))

    def forward(self, dec_outs, labels):
        scores = self.LogSoftmax(dec_outs)
        num_tokens = scores.size(-1)

        # print('label', labels[:10])
        # conduct label_smoothing module
        gtruth = labels.view(-1)
        # print('gtruth', gtruth[:10])
        if self.confidence < 1:
            tdata = gtruth.detach()
            one_hot = self._smooth_label(num_tokens)  # Do label smoothing, shape is [M]
            # print('one_hot', one_hot[:10])
            if labels.is_cuda:
                one_hot = one_hot.cuda()
            tmp_ = one_hot.repeat(gtruth.size(0), 1)  # [N, M]
            tmp_.scatter_(1, tdata.unsqueeze(1), self.confidence)  # after tdata.unsqueeze(1) , tdata shape is [N,1]
            gtruth = tmp_.detach()
            # print('gtruth',  gtruth[:10])
        loss = self.criterion(scores, gtruth)
        return loss

class Instructor(object):
    def __init__(self, args):
        super(Instructor, self).__init__()
        self.args = args
        self.device = args.device
        self.pre_best_auc_model, self.pre_best_acc_model = None, None
        self.post_best_acc_model, self.post_best_auc_model = None, None

        # 生成一个以epoch、lr参数和时间戳命名的文件夹名
        self.dir_name = get_dir_name(epoch=args.epoch, lr=args.lr,model_name='4_GPT_11')
        # 创建Logs、model文件夹，并以运行时间（年月日）+batch_size + epoch + Lr命名
        self.logs_name, self.model_name = mkdir(dir_name=self.dir_name)

        # step1 通过create_dataloaders获取训练数据和验证数据
        self.pre_train_factors, self.pre_train_labels, self.pre_test_factors, self.pre_test_labels = \
            pyh_dataloader(
                path=args.path, logs=self.logs_name)  # batch_size=args.batch_size
        dataset_train = Data.TensorDataset(self.pre_train_factors, self.pre_train_labels)
        self.data_iter_train = Data.DataLoader(dataset_train, batch_size=args.batch_size, shuffle=True)
        
        
        self.pre_train_len, self.pre_test_len = len(
            self.pre_train_labels), len(self.pre_test_labels)
        # step2 通过cfg 定义TabTransformer
        # 网络参数

        self.pre_model =  GPT(num_tokens=args.num_tokens, 
                              hidden_dim=args.hidden_dim, 
                              num_heads=args.num_heads, 
                              num_layers=args.num_layers,  
                              dropout=args.dropout).to(args.device)
        # step3 定义优化器和损失函数
        self.pre_optimizer = torch.optim.Adam(
            self.pre_model.parameters(), lr=args.lr, weight_decay=5e-4)
        # self.lr_scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=100, gamma=0.9,last_epoch=-1)
        self.pre_lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer=self.pre_optimizer,
                                                                           T_max=args.epoch + 200,
                                                                           eta_min=0, last_epoch=-1)
        # self.pre_loss_fn = nn.CrossEntropyLoss().to(self.device)
        #标签平滑
        self.pre_loss_fn = NMTCritierion(label_smoothing=0.3).to(self.args.device)

        self.feature_names = ['Lactate',	'pH',	'Anion Gap',	'Bicarbonate',	'Calcium',	'Chloride',	'Glucose',	'Potassium',
                              'Sodium',	'Hematocrit',	'Hemoglobin',
                              'Creatinine',	'UreaNitogen',	'Magnesium',	'Phosphate',
                              'PT',	'PTT',	'INR(PT)',
                              'Lymphocytes',	'Monocytes',	'Neutrophil',	'White_Blood_Cells',	'Basophils',	'Eosinophils',	'Platelet_Count',
                              'AlanineAminotransferase(ALT)',	'AlkalinePhosphatase',	'AspirateAminotransferase(AST)',	'Albumin',	'Bilirubin',
                              'MCH',	'MCHC',	'MCV',	'RDW',	'Red _Blood_Cells',	'patients_age', 'dead',
                              ]

        self.write = SummaryWriter(log_dir=self.logs_name)
        canshu='epoch: {:04d}'.format(args.epoch) + '\n'
        canshu=canshu+'batch_size: {:04d}'.format(args.batch_size) + '\n'
        canshu=canshu+'lr: {0:.4f}'.format(args.lr) + '\n'
        canshu=canshu+'num_tokens: {:04d}'.format(args.num_tokens) + '\n'
        canshu=canshu+'hidden_dim: {:04d}'.format(args.hidden_dim) + '\n'
        canshu=canshu+'num_heads: {:04d}'.format(args.num_heads) + '\n'
        canshu=canshu+'num_layers: {:04d}'.format(args.num_layers) + '\n'
        canshu=canshu+'dropout: {:04f}'.format(args.dropout) + '\n'
        with open(os.path.join(self.logs_name,
                                   "canshu.txt"), mode="a") as f:
                f.write(canshu)

    def train(self):
        pre_best_auc, pre_best_auc_acc = torch.tensor(
            [0.], dtype=torch.float32), torch.tensor([0.], dtype=torch.float32)
        pre_best_acc, pre_best_acc_auc = torch.tensor(
            [0.], dtype=torch.float32), torch.tensor([0.], dtype=torch.float32)
        pre_best_acc_epoch = 0
        
        for i in range(self.args.epoch):
            pre_start_time = time.time()
            self.pre_model.train()
            pre_train_accuracy=0.0
            for step, (train_factors, train_labels) in enumerate(self.data_iter_train):
                pre_train_outputs = self.pre_model(torch.unsqueeze(
                    input=train_factors, dim=1).to(self.device))
                # pre_train_outputs = self.pre_model(self.pre_train_factors.to(self.device))

                pre_train_loss = self.pre_loss_fn(
                    pre_train_outputs, train_labels.to(self.device))
                pre_train_loss.backward()
                self.pre_optimizer.step()
                self.pre_optimizer.zero_grad()
                # 训练集预测正确样本数
                pre_train_accuracy =pre_train_accuracy+ (pre_train_outputs.detach().cpu().argmax(
                    axis=1) == train_labels).sum()
            # argmax(axis=1): 返回每一行最大值的索引
            self.pre_lr_scheduler.step()  # 更新学习率
            '''
            #将标量添加到 summary
            # tag (string)：数据标识符，训练集损失
            # scalar_value (float or string/blobname)：要保存的数值
            # global_step (int)：全局步值
            '''
            self.write.add_scalar(
                    tag='pre_train_loss', scalar_value=pre_train_loss.detach().cpu(), global_step=i)
            self.write.add_scalar(tag='pre_train_acc', scalar_value=pre_train_accuracy / self.pre_train_len,
                                    global_step=i)

            self.pre_model.eval()
            with torch.no_grad():
                pre_test_outputs = self.pre_model(torch.unsqueeze(
                        input=self.pre_test_factors, dim=1).to(self.device))
                pre_test_loss = self.pre_loss_fn(
                        pre_test_outputs, self.pre_test_labels.to(self.device))
            
                # 测试集预测正确样本数
                pre_test_accuracy = (pre_test_outputs.cpu().argmax(
                    axis=1) == self.pre_test_labels).sum()
            # 计算auc
            pre_auc = roc_auc_score(
                self.pre_test_labels, pre_test_outputs[:, -1].cpu())

            self.write.add_scalar(
                tag='pre_test_loss', scalar_value=pre_test_loss.cpu(), global_step=i)
            self.write.add_scalar(tag='pre_test_acc', scalar_value=pre_test_accuracy / self.pre_test_len,
                                  global_step=i)

            if (pre_test_accuracy / self.pre_test_len) > pre_best_acc:
                self.pre_best_acc_model = copy.deepcopy(self.pre_model)
                pre_best_acc = pre_test_accuracy / self.pre_test_len  # 更新测试集准确率
                pre_best_acc_auc = pre_auc  # 更新测试集auc(acc最高时的auc)
                # 模型保存
                torch.save(self.pre_best_acc_model.state_dict(), os.path.join(
                    self.logs_name, 'pre_best_acc_model.pth'))
                pre_best_acc_epoch = i+1
                # print('pre_best_acc_epoch', pre_best_acc_epoch)

            if pre_auc > pre_best_auc:
                pre_best_auc = pre_auc  # 更新auc
                pre_best_auc_acc = pre_test_accuracy / self.pre_test_len  # auc最高时的acc
            # print("pre_train_accuracy / self.pre_train_len",pre_train_accuracy , self.pre_train_len)
            if (i+1) % 10 == 0:
                print('pre_Epoch: {:04d}'.format(i+1),
                      'pre_train_loss: {:.4f}'.format(
                          pre_train_loss.detach().cpu().item()),  # .item()的目的是只取张量的数值
                      'pre_train_acc: {:.4f}'.format(
                          (pre_train_accuracy / self.pre_train_len).item()),
                      'pre_val_loss: {:.4f}'.format(
                          pre_test_loss.cpu().item()),
                      'pre_val_acc: {:.4f}'.format(
                          (pre_test_accuracy / self.pre_test_len).item()),
                      'pre_lr: {:.4f}s'.format(
                          self.pre_optimizer.param_groups[0]['lr']),
                      'pre_time: {:.4f}s'.format(time.time() - pre_start_time))

            # # ----------------------------------#   

    def result(self):
        print('记录结果')

        filtering_model = self.pre_best_acc_model
        filtering_model.eval()

        with torch.no_grad():
            train_outputs = filtering_model(torch.unsqueeze(
                input=self.pre_train_factors, dim=1).to(self.device))
            train_auc = roc_auc_score(
                self.pre_train_labels, train_outputs[:, -1].cpu())

        pre_train_prediction_labels = np.argmax(
            np.array(train_outputs.cpu()), axis=1)  # 预测标签
        tpo, fpo, tno, fno = 1e-8, 1e-8, 1e-8, 1e-8
        for j in range(self.pre_train_len):
            if (self.pre_train_labels.numpy())[j] == 1:
                if pre_train_prediction_labels[j] == 1:
                    tpo = tpo + 1
                else:
                    fno = fno + 1
            else:
                if pre_train_prediction_labels[j] == 1:
                    fpo = fpo + 1
                else:
                    tno = tno + 1

        ppro = tpo / (tpo + fpo)  # 查准率
        npro = tno / (tno + fno)
        recallo = tpo / (tpo + fno)  # 查全率
        precisiono = tpo / (tpo + fpo)
        F1o = (2 * precisiono * recallo) / (precisiono + recallo)
        acco = (tpo + tno) / self.pre_train_len
        MCCo = (tpo * tno - fpo * fno) / math.sqrt((tpo + fpo)
                                                   * (tpo + fno) * (tno + fpo) * (tno + fno))
        s = open(os.path.join(self.logs_name,
                 "pre_confusion_matrix.txt"), mode="a")

        s.write('{}'.format(args.path))
        s.write('\n\ntrain\n'
                f"tp          fp          tn          fn          ppr          npr \n"
                f"{'%.4f' % tpo}   {'%.4f' % fpo}   {'%.4f' % tno}   {'%.4f' % fno}   {'%.4f' % ppro}   {'%.4f' % npro}\n"
                f"accuracy  precision   recall  F1  AUC  MCC\n"
                f"{'%.4f' % acco}   {'%.4f' % precisiono}   {'%.4f' % recallo}  {'%.4f' % F1o}   {'%.4f' % train_auc}   {'%.4f' % MCCo}")

        with torch.no_grad():
            test_outputs = filtering_model(torch.unsqueeze(
                input=self.pre_test_factors, dim=1).to(self.device))
            test_auc = roc_auc_score(
                self.pre_test_labels, test_outputs[:, -1].cpu())
            test_accuracy = (test_outputs.cpu().argmax(
                axis=1) == self.pre_test_labels).sum()
        pre_test_prediction_labels = np.argmax(
            np.array(test_outputs.cpu()), axis=1)  # 预测标签
        tp, fp, tn, fn = 1e-8, 1e-8, 1e-8, 1e-8
        for j in range(self.pre_test_len):
            if (self.pre_test_labels.numpy())[j] == 1:
                if pre_test_prediction_labels[j] == 1:
                    tp = tp + 1
                else:
                    fn = fn + 1
            else:
                if pre_test_prediction_labels[j] == 1:
                    fp = fp + 1
                else:
                    tn = tn + 1
        ppr = tp / (tp + fp)  # 查准率 精确率   precision
        npr = tn / (tn + fn)  #

        precision = tp / (tp + fp)
        recall = tp / (tp + fn)  # 查全率
        F1 = (2 * precision * recall) / (precision + recall)
        acc = (tp + tn) / self.pre_test_len
        MCC = (tp * tn - fp * fn) / math.sqrt((tp + fp)
                                              * (tp + fn) * (tn + fp) * (tn + fn))
        s = open(os.path.join(self.logs_name,
                 "pre_confusion_matrix.txt"), mode="a")

        s.write('\n\ntest\n'
                f"tp          fp          tn          fn          ppr          npr\n"
                f"{'%.4f' % tp}   {'%.4f' % fp}   {'%.4f' % tn}   {'%.4f' % fn}   {'%.4f' % ppr}   {'%.4f' % npr}\n"
                f"accuracy  precision   recall  F1  AUC  MCC\n"
                f"{'%.4f' % acc}   {'%.4f' % precision}   {'%.4f' % recall}  {'%.4f' % F1}   {'%.4f' % test_auc}   {'%.4f' % MCC}")
        s.close()

    

        #训练结果
        post_train_results = pd.DataFrame(
            (train_outputs.cpu()).numpy())  # best_model的输出结果
        post_train_results.to_csv(os.path.join(#保存
            self.logs_name, './pre_train_outputs.csv'), header=False, index=False)
        #训练集真正的标签
        post_train_real_labels = pd.DataFrame(self.pre_train_labels)
        #保存
        post_train_real_labels.to_csv(os.path.join(self.logs_name, './pre_train_real_labels.csv'), header=False,
                                      index=False)
        #测试集结果保存
        post_test_results = pd.DataFrame(
            (test_outputs.cpu()).numpy())  # best_model的输出结果
        
        post_test_results.to_csv(os.path.join(
            self.logs_name, './pre_test_outputs.csv'), header=False, index=False)
        #测试集标签
        post_test_real_labels = pd.DataFrame(self.pre_test_labels)
        post_test_real_labels.to_csv(os.path.join(self.logs_name, './pre_test_real_labels.csv'), header=False,
                                     index=False)
        # torch.Size([4964, 2])
        print('pre_pyh_train_outputs.shape',train_outputs.shape)
        # torch.Size([2128, 2])
        print('pre_pyh_train_outputs.shape', test_outputs.shape)
        
        y_test = self.pre_test_labels.cpu()
        pred = test_outputs[:, -1].cpu()
        print(pred)
        logpathroc = os.path.join(self.logs_name, "./roc.png")
        print("auc:", roc_auc_score(y_test, pred))
        fpr, tpr, thersholds = roc_curve(y_test, pred)
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, 'k-',
                 label='ROC (area = {0:.2f})'.format(roc_auc), color='blue', lw=2)
        plt.xlim([-0.05, 1.05])
        plt.ylim([-0.05, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve')
        plt.legend(loc="lower right")
        plt.plot([0, 1], [0, 1], 'k--')
        plt.savefig(logpathroc, bbox_inches='tight')
        plt.show()
  
def hyperParameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('--device', type=str, default='cuda:0',
                        help='device')

    parser.add_argument('--lr', type=float, default=2e-4,
                        help='Initial learning rate.')

    parser.add_argument('--epoch', type=int, default=2000,
                        help='Number of epochs to train.')

    parser.add_argument('--batch_size', type=int, default=200,
                        help='Number of loading.')

    parser.add_argument(
        '--path', type=str, default='data/mimic4_3813_11_log_smote2.csv', help='data path.')
    parser.add_argument('--num_tokens', type=int, default=11,
                        help='Number of epochs to train.')
    parser.add_argument('--hidden_dim', type=int, default=11,
                        help='Number of epochs to train.')
    parser.add_argument('--num_heads', type=int, default=11,
                        help='Number of epochs to train.')
    parser.add_argument('--num_layers', type=int, default=8,
                        help='Number of epochs to train.')
    parser.add_argument('--dropout', type=float, default=0.1,
                        help='Number of epochs to train.')
    opts = parser.parse_args()
    return opts


if __name__ == '__main__':
    print(__file__)
    args = hyperParameters()
    print(torch.cuda.is_available())
    # 执行此命令，则创建了Log、model文件夹，并以运行时间（年月日）+batch_size + epoch + Lr命名
    entity = Instructor(args)
    entity.train()
    entity.result()
    
