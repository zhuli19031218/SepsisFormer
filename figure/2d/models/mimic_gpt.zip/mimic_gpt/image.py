import matplotlib.pyplot as plt
from itertools import islice
from matplotlib.pyplot import MultipleLocator
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import confusion_matrix,accuracy_score,f1_score,roc_auc_score,recall_score,precision_score,roc_curve
#支持中文显示
from pylab import *
mpl.rcParams['font.sans-serif'] = ['SimHei']

#绘制单个ROC曲线图
def draw_roc(y_test, pred,logpathroc):
    print("auc:",roc_auc_score(y_test, pred))
    fpr, tpr, thersholds = roc_curve(y_test, pred)
    roc_auc = auc(fpr, tpr)
    plt.plot(fpr, tpr, 'k-', label='ROC (area = {0:.2f})'.format(roc_auc),color='blue', lw=2)
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve')
    plt.legend(loc="lower right")
    plt.plot([0, 1], [0, 1], 'k--')
    plt.savefig(logpathroc,bbox_inches='tight')
    plt.show()


def draw_image(path,logpath,epochnum):
    file=open(path,"r", encoding='UTF-8')
    pre_train_loss = []
    pre_train_acc = []
    pre_val_loss=[]
    pre_val_acc=[]
    epoch=[]
    epochnum=int(epochnum)
    for x in range(1,epochnum):
        epoch.append(int(x))
    for line in islice(file, 1, None):
        # pre_train_loss.append(float(line[32:38]))
        pre_train_acc.append(float(line[54:60]))
        # pre_val_loss.append(float(line[75:81]))  
        pre_val_acc.append(float(line[95:101]))
    # plt.plot(epoch,pre_train_loss,label='pre_train_loss')
    plt.plot(epoch,pre_train_acc,label='pre_train_acc')
    # plt.plot(epoch,pre_val_loss,label='pre_val_loss')
    plt.plot(epoch,pre_val_acc,label='pre_val_acc')

    plt.title("训练、测试结果图")
    plt.xlabel("epoch")
    plt.ylabel("val")
    plt.legend(loc='upper right')
    plt.savefig(logpath,bbox_inches='tight')
    plt.show()    
    file.close()

if __name__ == '__main__':
    print('绘图')
    # path=r"E:\nzl\MM_Transformer\logs\20221129-16-41_epoch1500_lr0.0004\traindata.txt"
    # pathlog=r"E:\nzl\MM_Transformer\logs\20221129-16-41_epoch1500_lr0.0004\image1.jpg"
    # epochnum=1500
    # draw_image(path,pathlog,epochnum)
